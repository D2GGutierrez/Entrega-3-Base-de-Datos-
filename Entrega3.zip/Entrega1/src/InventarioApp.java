import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Vector;

public class InventarioApp extends JFrame {

    // Configuración de Conexión (Basado en tus PDFs)
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    private static final String DB_USER = "system";
    private static final String DB_PASSWORD = "Abril131123"; // Contraseña del PDF

    // Componentes de la UI
    private JTextField txtId, txtNombre, txtPrecio, txtStock;
    private JComboBox<CategoriaItem> cmbCategoria;
    private JComboBox<String> cmbEstado;
    private JTable tablaProductos;
    private DefaultTableModel modeloTabla;

    public InventarioApp() {
        setTitle("Sistema de Inventario - Entrega 3");
        setSize(1000, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // TITULO
        JPanel pnlHeader = new JPanel();
        pnlHeader.setBackground(new Color(44, 62, 80));
        JLabel lblTitulo = new JLabel("GESTIÓN DE INVENTARIO (Oracle DB)");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 20));
        pnlHeader.add(lblTitulo);
        add(pnlHeader, BorderLayout.NORTH);

        // PANEL IZQUIERDO (FORMULARIO)
        JPanel pnlFormulario = new JPanel(new GridBagLayout());
        pnlFormulario.setBorder(BorderFactory.createTitledBorder("Datos del Producto"));
        pnlFormulario.setPreferredSize(new Dimension(300, 0));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // CAMPOS
        agregarCampo(pnlFormulario, "ID (Auto):", txtId = new JTextField(), gbc, 0, false);
        agregarCampo(pnlFormulario, "Nombre:", txtNombre = new JTextField(), gbc, 1, true);
        agregarCampo(pnlFormulario, "Precio:", txtPrecio = new JTextField(), gbc, 2, true);
        agregarCampo(pnlFormulario, "Stock:", txtStock = new JTextField(), gbc, 3, true);

        // CATEGORIAS
        gbc.gridx = 0; gbc.gridy = 4;
        pnlFormulario.add(new JLabel("Categoría:"), gbc);
        gbc.gridx = 1;
        cmbCategoria = new JComboBox<>();
        pnlFormulario.add(cmbCategoria, gbc);

        // ESTADO
        gbc.gridx = 0; gbc.gridy = 5;
        pnlFormulario.add(new JLabel("Estado:"), gbc);
        gbc.gridx = 1;
        cmbEstado = new JComboBox<>(new String[]{"ACTIVO", "INACTIVO"});
        pnlFormulario.add(cmbEstado, gbc);

        // BOTONES
        JPanel pnlBotones = new JPanel(new GridLayout(1, 3, 5, 5));
        JButton btnGuardar = new JButton("Guardar");
        JButton btnEditar = new JButton("Actualizar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnLimpiar = new JButton("Limpiar");

        // ESTILO DE LOS BOTONES
        estilarBoton(btnGuardar, new Color(46, 204, 113));
        estilarBoton(btnEditar, new Color(52, 152, 219));
        estilarBoton(btnEliminar, new Color(231, 76, 60));

        gbc.gridx = 0; gbc.gridy = 6; gbc.gridwidth = 2;
        pnlBotones.add(btnGuardar);
        pnlBotones.add(btnEditar);
        pnlBotones.add(btnEliminar);
        pnlFormulario.add(pnlBotones, gbc);

        gbc.gridy = 7;
        pnlFormulario.add(btnLimpiar, gbc);

        add(pnlFormulario, BorderLayout.WEST);

        // PANEL CENTRAL (TABLA)
        // COLUMNAS PARA LAS TABLAS
        String[] columnas = {"ID", "Nombre", "Precio", "Stock", "Categoría", "Estado", "Fecha"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        tablaProductos = new JTable(modeloTabla);
        add(new JScrollPane(tablaProductos), BorderLayout.CENTER);

        // EVENTOS
        cargarCategorias();
        cargarTabla();

        btnGuardar.addActionListener(e -> guardarProducto());
        btnEditar.addActionListener(e -> actualizarProducto());
        btnEliminar.addActionListener(e -> eliminarProducto());
        btnLimpiar.addActionListener(e -> limpiarFormulario());

        // EVENTO CUANDO HACEMOS CLICK EN LA TABLA PARA LLENAR EL FORMULARIO
        tablaProductos.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int fila = tablaProductos.getSelectedRow();
                if (fila >= 0) {
                    txtId.setText(modeloTabla.getValueAt(fila, 0).toString());
                    txtNombre.setText(modeloTabla.getValueAt(fila, 1).toString());
                    txtPrecio.setText(modeloTabla.getValueAt(fila, 2).toString());
                    txtStock.setText(modeloTabla.getValueAt(fila, 3).toString());

                    String catNombre = modeloTabla.getValueAt(fila, 4).toString();
                    seleccionarCategoriaPorNombre(catNombre);

                    cmbEstado.setSelectedItem(modeloTabla.getValueAt(fila, 5).toString());
                }
            }
        });
    }

    // MÉTODOS DE BASE DE DATOS

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    // MOSTRAR RESULTADOS DE VISTA
    private void cargarTabla() {
        modeloTabla.setRowCount(0);
        // USAMOS LA VISTA CREADA
        String sql = "SELECT * FROM V_DETALLE_PRODUCTOS";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Object[] fila = {
                        rs.getInt("ID_PRODUCTO"),
                        rs.getString("NOMBRE_PRODUCTO"),
                        rs.getDouble("PRECIO"),
                        rs.getInt("STOCK"),
                        rs.getString("CATEGORIA"),
                        rs.getString("ESTADO"),
                        rs.getDate("FECHA_REGISTRO")
                };
                modeloTabla.addRow(fila);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al cargar tabla: " + e.getMessage());
        }
    }

    private void cargarCategorias() {
        cmbCategoria.removeAllItems();
        String sql = "SELECT ID_CATEGORIA, NOMBRE FROM CATEGORIAS ORDER BY ID_CATEGORIA";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                cmbCategoria.addItem(new CategoriaItem(rs.getInt("ID_CATEGORIA"), rs.getString("NOMBRE")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // REQUISITO: Invocar procedimientos almacenados (INSERTAR)
    private void guardarProducto() {
        if (txtNombre.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio");
            return;
        }

        // LLAMAR AL PROCEDIMIENTO DE ALMACENAR
        String sql = "{call SP_INSERTAR_PRODUCTO(?, ?, ?, ?, ?)}";

        try (Connection conn = getConnection();
             CallableStatement cs = conn.prepareCall(sql)) {

            cs.setString(1, txtNombre.getText());
            cs.setDouble(2, Double.parseDouble(txtPrecio.getText()));
            cs.setInt(3, Integer.parseInt(txtStock.getText()));

            CategoriaItem cat = (CategoriaItem) cmbCategoria.getSelectedItem();
            cs.setInt(4, cat.getId());

            cs.setString(5, cmbEstado.getSelectedItem().toString());

            cs.execute();
            JOptionPane.showMessageDialog(this, "Producto Guardado Correctamente");
            limpiarFormulario();
            cargarTabla();

        } catch (SQLException | NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage());
        }
    }

    private void actualizarProducto() {
        if (txtId.getText().isEmpty()) return;

        String sql = "{call SP_ACTUALIZAR_PRODUCTO(?, ?, ?, ?, ?)}";

        try (Connection conn = getConnection();
             CallableStatement cs = conn.prepareCall(sql)) {

            cs.setInt(1, Integer.parseInt(txtId.getText()));
            cs.setString(2, txtNombre.getText());
            cs.setDouble(3, Double.parseDouble(txtPrecio.getText()));
            cs.setInt(4, Integer.parseInt(txtStock.getText()));
            cs.setString(5, cmbEstado.getSelectedItem().toString());

            cs.execute();
            JOptionPane.showMessageDialog(this, "Producto Actualizado");
            limpiarFormulario();
            cargarTabla();

        } catch (SQLException | NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Error al actualizar: " + e.getMessage());
        }
    }

    private void eliminarProducto() {
        if (txtId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Seleccione un producto primero");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "¿Estás seguro de eliminar este producto?");
        if (confirm != JOptionPane.YES_OPTION) return;

        String sql = "{call SP_ELIMINAR_PRODUCTO(?)}";

        try (Connection conn = getConnection();
             CallableStatement cs = conn.prepareCall(sql)) {

            cs.setInt(1, Integer.parseInt(txtId.getText()));
            cs.execute();

            JOptionPane.showMessageDialog(this, "Producto Eliminado");
            limpiarFormulario();
            cargarTabla();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error al eliminar: " + e.getMessage());
        }
    }

    // UTIILIDADES

    private void limpiarFormulario() {
        txtId.setText("");
        txtNombre.setText("");
        txtPrecio.setText("");
        txtStock.setText("");
        cmbCategoria.setSelectedIndex(0);
        cmbEstado.setSelectedIndex(0);
        tablaProductos.clearSelection();
    }

    private void agregarCampo(JPanel panel, String label, JTextField field, GridBagConstraints gbc, int y, boolean editable) {
        gbc.gridx = 0; gbc.gridy = y;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        field.setEditable(editable);
        if(!editable) field.setBackground(new Color(230, 230, 230));
        panel.add(field, gbc);
    }

    private void estilarBoton(JButton btn, Color color) {
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Arial", Font.BOLD, 12));
    }

    private void seleccionarCategoriaPorNombre(String nombreCat) {
        for (int i = 0; i < cmbCategoria.getItemCount(); i++) {
            if (cmbCategoria.getItemAt(i).toString().equals(nombreCat)) {
                cmbCategoria.setSelectedIndex(i);
                break;
            }
        }
    }

    // CLASE AUXILIAR PARA GUARDAR ID Y NOMBRE EN EL COMBOBOX
    class CategoriaItem {
        private int id;
        private String nombre;

        public CategoriaItem(int id, String nombre) {
            this.id = id;
            this.nombre = nombre;
        }
        public int getId() { return id; }
        public String toString() { return nombre; }
    }

    public static void main(String[] args) {
        // ESTILO VISUAL DEL SISTEMA OPERATIVO
        try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception e) {}

        SwingUtilities.invokeLater(() -> {
            new InventarioApp().setVisible(true);
        });
    }
}